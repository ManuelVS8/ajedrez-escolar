/* ============================================================
   CONFIGURACIÓN DEL CENTRO
   Lo más fácil: abre «configurador.html», rellena el formulario
   y sustituye este archivo por el config.js que se descarga.
   (Si prefieres hacerlo a mano, rellena lo que va entre comillas.)
   ============================================================ */
window.APP_CFG = {
  // Nombre de la app (cabecera, al instalarla, en el diploma…). Ej.: "Ajedrez Cervantes"
  app: "",
  // Nombre corto (app de administración: «Cervantes Admin»). Ej.: "Cervantes"
  corto: "",
  // Centro y localidad. Ej.: "CEIP Miguel de Cervantes", "Huelva"
  centro: "",
  localidad: "",
  // Dirección web de la app (sale en las tarjetas de claves). Ej.: "micole.github.io/ajedrez"
  web: "",

  // Imágenes subidas junto a index.html (déjalo en "" si no tienes)
  logo: "",          // ej.: "logo.png"
  insignia: "",      // ej.: "insignia.png"
  insigniaAlt: "Insignia del centro",

  // Pestaña «YouTubers»: son saludos grabados para otro centro. Déjalo en false.
  youtubers: false,

  // Correo de la cuenta de administración (el mismo que pongas en las reglas de Firebase)
  admin: "",

  // Dominio inventado para las cuentas del alumnado (usuario@dominio). No tiene que existir.
  // ¡No cambiarlo después de dar de alta cuentas!
  dominioUsuarios: "",

  // Datos de Firebase (Configuración del proyecto → Tus apps → app web)
  firebase: {
    apiKey: "",
    projectId: "",
    databaseURL: ""
  }
};
